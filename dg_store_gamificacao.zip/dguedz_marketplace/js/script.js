// JavaScript para DG Store - Versão Expandida

// Inicialização do player do YouTube
let playerDetective;

function onYouTubeIframeAPIReady() {
  const videoIdDetective = 'KA3og1jDav8'; // ID REAL INSERIDO
  
  playerDetective = new YT.Player('youtube-player-detective', {
    videoId: videoIdDetective,
    playerVars: {
      'autoplay': 0,
      'controls': 1,
      'rel': 0,
      'showinfo': 0
    }
  });
}

// Slider Hero
let currentSlide = 0;
const slides = document.querySelectorAll('#hero-slider .slide');
const totalSlides = slides.length;

function showSlide(index) {
  // Esconder todos os slides
  slides.forEach(slide => {
    slide.classList.remove('active');
  });
  
  // Mostrar o slide atual
  slides[index].classList.add('active');
}

function nextSlide() {
  currentSlide = (currentSlide + 1) % totalSlides;
  showSlide(currentSlide);
}

// Iniciar o slider
setInterval(nextSlide, 5000); // Trocar slide a cada 5 segundos

// Carrinho de Compras
let carrinho = [];
let total = 0;

// Preços dos produtos
const precos = {
  'beat_detective': {
    'simples': 300,
    'stems_feat': 500,
    'exclusiva_visualizer': 1500
  }
};

function adicionarAoCarrinho(produto, licenca) {
  // Verificar se o produto existe
  if (precos[produto] && precos[produto][licenca]) {
    const preco = precos[produto][licenca];
    
    // Adicionar ao carrinho
    carrinho.push({
      produto: produto,
      licenca: licenca,
      preco: preco
    });
    
    // Atualizar total
    total += preco;
    
    // Atualizar a visualização do carrinho
    atualizarCarrinho();
    
    // Notificar o usuário
    alert(`Produto adicionado ao carrinho: ${produto} (${licenca}) - R$ ${preco.toFixed(2)}`);
  }
}

function atualizarCarrinho() {
  const carrinhoElement = document.getElementById('itens-carrinho');
  const totalElement = document.getElementById('total-carrinho');
  const contagemElement = document.getElementById('contagem-carrinho');
  
  // Atualizar contagem
  contagemElement.textContent = carrinho.length;
  
  // Se o carrinho estiver vazio
  if (carrinho.length === 0) {
    carrinhoElement.innerHTML = '<p>Seu carrinho está vazio.</p>';
    totalElement.textContent = 'Total: R$ 0,00';
    return;
  }
  
  // Construir HTML dos itens
  let html = '<ul>';
  
  carrinho.forEach((item, index) => {
    let nomeProduto = '';
    let descricaoLicenca = '';
    
    // Determinar nome do produto
    if (item.produto === 'beat_detective') {
      nomeProduto = 'DG Detective';
      
      // Determinar descrição da licença
      if (item.licenca === 'simples') {
        descricaoLicenca = 'Licença Simples';
      } else if (item.licenca === 'stems_feat') {
        descricaoLicenca = 'Licença + Stems + Feat';
      } else if (item.licenca === 'exclusiva_visualizer') {
        descricaoLicenca = 'Licença Exclusiva + Visualizer';
      }
    }
    
    html += `
      <li>
        ${nomeProduto} - ${descricaoLicenca} - R$ ${item.preco.toFixed(2)}
        <button onclick="removerDoCarrinho(${index})">Remover</button>
      </li>
    `;
  });
  
  html += '</ul>';
  
  // Atualizar elementos
  carrinhoElement.innerHTML = html;
  totalElement.textContent = `Total: R$ ${total.toFixed(2)}`;
}

function removerDoCarrinho(index) {
  // Verificar se o índice é válido
  if (index >= 0 && index < carrinho.length) {
    // Subtrair do total
    total -= carrinho[index].preco;
    
    // Remover do carrinho
    carrinho.splice(index, 1);
    
    // Atualizar a visualização
    atualizarCarrinho();
  }
}

function iniciarCheckout() {
  if (carrinho.length === 0) {
    alert('Seu carrinho está vazio. Adicione produtos antes de finalizar a compra.');
    return;
  }
  
  // Aqui seria a integração com o backend para processamento do pagamento
  alert('Funcionalidade de checkout pendente de implementação do backend.');
}

// Whitelist Modal
let categoriaAtual = '';

function showWhitelistModal(categoria) {
  const modal = document.getElementById('whitelist-modal');
  const titulo = modal.querySelector('p');
  
  categoriaAtual = categoria;
  
  // Atualizar texto baseado na categoria
  titulo.textContent = `Seja o primeiro a saber sobre o lançamento de ${categoria}!`;
  
  // Mostrar modal
  modal.style.display = 'block';
}

function closeWhitelistModal() {
  const modal = document.getElementById('whitelist-modal');
  modal.style.display = 'none';
}

// Outlet Tabs
function showOutletCategory(category) {
  // Esconder todas as categorias
  const categories = document.querySelectorAll('.outlet-category');
  categories.forEach(cat => {
    cat.classList.remove('active');
  });
  
  // Mostrar a categoria selecionada
  document.getElementById(category).classList.add('active');
  
  // Atualizar tabs
  const tabs = document.querySelectorAll('.outlet-tab');
  tabs.forEach(tab => {
    tab.classList.remove('active');
  });
  
  // Encontrar e ativar a tab correspondente
  const activeTab = Array.from(tabs).find(tab => {
    return tab.getAttribute('onclick').includes(category);
  });
  
  if (activeTab) {
    activeTab.classList.add('active');
  }
}

// Inicialização quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', function() {
  // Inicializar o carrinho
  atualizarCarrinho();
  
  // Inicializar o slider
  showSlide(currentSlide);
  
  // Inicializar a primeira categoria do Outlet
  showOutletCategory('jerseys');
});
