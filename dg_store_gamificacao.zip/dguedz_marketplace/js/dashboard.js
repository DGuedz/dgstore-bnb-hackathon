// Dashboard Interativo - DG Store
// Arquivo responsável pela simulação de dados e renderização dos gráficos

// Dados simulados para o dashboard
const dashboardData = {
    // Dados gerais
    overview: {
        youtube: {
            subscribers: 25800,
            growth: 12.5
        },
        spotify: {
            monthlyListeners: 18300,
            growth: 8.7
        },
        views: {
            total: 1200000,
            growth: 15.3
        },
        streams: {
            total: 850000,
            growth: 9.2
        },
        audienceGrowth: {
            labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'],
            datasets: [
                {
                    label: 'YouTube',
                    data: [18500, 19800, 21200, 22900, 24300, 25800],
                    borderColor: '#FF0000',
                    backgroundColor: 'rgba(255, 0, 0, 0.1)',
                    tension: 0.4
                },
                {
                    label: 'Spotify',
                    data: [12800, 14200, 15500, 16300, 17500, 18300],
                    borderColor: '#1DB954',
                    backgroundColor: 'rgba(29, 185, 84, 0.1)',
                    tension: 0.4
                }
            ]
        },
        platformDistribution: {
            labels: ['YouTube', 'Spotify', 'Instagram', 'Twitter', 'Facebook', 'TikTok'],
            datasets: [
                {
                    data: [35, 25, 15, 10, 10, 5],
                    backgroundColor: [
                        '#FF0000',
                        '#1DB954',
                        '#E1306C',
                        '#1DA1F2',
                        '#4267B2',
                        '#000000'
                    ],
                    borderWidth: 0
                }
            ]
        }
    },
    
    // Dados do YouTube
    youtube: {
        subscribers: 25800,
        views: 1200000,
        watchHours: 45200,
        engagement: 8.7,
        videoViews: {
            labels: ['DG Detective', 'Afro Vibes Vol. 1', 'Freestyle #3', 'Started From The Bottom', 'In The Air'],
            datasets: [
                {
                    label: 'Visualizações',
                    data: [152300, 98700, 87200, 65400, 48900],
                    backgroundColor: 'rgba(255, 0, 0, 0.7)',
                    borderColor: '#FF0000',
                    borderWidth: 1
                }
            ]
        },
        subscribersGrowth: {
            labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'],
            datasets: [
                {
                    label: 'Inscritos',
                    data: [18500, 19800, 21200, 22900, 24300, 25800],
                    borderColor: '#FF0000',
                    backgroundColor: 'rgba(255, 0, 0, 0.1)',
                    tension: 0.4,
                    fill: true
                }
            ]
        },
        topVideos: [
            {
                title: 'DG Detective – (Rema Type Beat)',
                views: 152300,
                thumbnail: 'https://img.youtube.com/vi/KA3og1jDav8/mqdefault.jpg'
            },
            {
                title: 'Afro Vibes Vol. 1 - Teaser',
                views: 98700,
                thumbnail: 'https://img.youtube.com/vi/KA3og1jDav8/mqdefault.jpg'
            },
            {
                title: 'DG Freestyle Session #3',
                views: 87200,
                thumbnail: 'https://img.youtube.com/vi/KA3og1jDav8/mqdefault.jpg'
            }
        ]
    },
    
    // Dados do Spotify
    spotify: {
        monthlyListeners: 18300,
        totalStreams: 850000,
        playlists: 325,
        followers: 12500,
        trackStreams: {
            labels: ['DG Detective', 'Afro Vibes Intro', 'Started From The Bottom', 'In The Air', 'Insólito'],
            datasets: [
                {
                    label: 'Streams',
                    data: [235800, 187300, 142900, 98500, 76200],
                    backgroundColor: 'rgba(29, 185, 84, 0.7)',
                    borderColor: '#1DB954',
                    borderWidth: 1
                }
            ]
        },
        listenersByCountry: {
            labels: ['Brasil', 'EUA', 'Portugal', 'Angola', 'França', 'Outros'],
            datasets: [
                {
                    label: 'Ouvintes',
                    data: [65, 12, 8, 6, 4, 5],
                    backgroundColor: [
                        'rgba(29, 185, 84, 0.8)',
                        'rgba(29, 185, 84, 0.7)',
                        'rgba(29, 185, 84, 0.6)',
                        'rgba(29, 185, 84, 0.5)',
                        'rgba(29, 185, 84, 0.4)',
                        'rgba(29, 185, 84, 0.3)'
                    ],
                    borderWidth: 0
                }
            ]
        },
        topTracks: [
            {
                title: 'DG Detective',
                streams: 235800
            },
            {
                title: 'Afro Vibes Intro',
                streams: 187300
            },
            {
                title: 'Started From The Bottom',
                streams: 142900
            },
            {
                title: 'In The Air',
                streams: 98500
            },
            {
                title: 'Insólito',
                streams: 76200
            }
        ]
    },
    
    // Dados de redes sociais
    social: {
        instagram: {
            followers: 45200,
            growth: 5.7
        },
        twitter: {
            followers: 22800,
            growth: 3.9
        },
        facebook: {
            followers: 38500,
            growth: 2.3
        },
        tiktok: {
            followers: 15700,
            growth: 18.5
        },
        engagement: {
            labels: ['Instagram', 'Twitter', 'Facebook', 'TikTok'],
            datasets: [
                {
                    label: 'Taxa de Engajamento (%)',
                    data: [4.8, 2.3, 1.5, 7.2],
                    backgroundColor: [
                        'rgba(225, 48, 108, 0.7)',
                        'rgba(29, 161, 242, 0.7)',
                        'rgba(66, 103, 178, 0.7)',
                        'rgba(0, 0, 0, 0.7)'
                    ],
                    borderWidth: 1
                }
            ]
        },
        followersGrowth: {
            labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'],
            datasets: [
                {
                    label: 'Instagram',
                    data: [38500, 40200, 41800, 43100, 44300, 45200],
                    borderColor: '#E1306C',
                    backgroundColor: 'rgba(0, 0, 0, 0)',
                    tension: 0.4
                },
                {
                    label: 'Twitter',
                    data: [19800, 20500, 21200, 21900, 22400, 22800],
                    borderColor: '#1DA1F2',
                    backgroundColor: 'rgba(0, 0, 0, 0)',
                    tension: 0.4
                },
                {
                    label: 'Facebook',
                    data: [35200, 36100, 36800, 37400, 38000, 38500],
                    borderColor: '#4267B2',
                    backgroundColor: 'rgba(0, 0, 0, 0)',
                    tension: 0.4
                },
                {
                    label: 'TikTok',
                    data: [8500, 10200, 11800, 13500, 14800, 15700],
                    borderColor: '#000000',
                    backgroundColor: 'rgba(0, 0, 0, 0)',
                    tension: 0.4
                }
            ]
        }
    }
};

// Função para formatar números grandes (K, M)
function formatNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    }
    if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'K';
    }
    return num;
}

// Função para alternar entre as abas do dashboard
function showDashboardTab(tabId) {
    // Esconder todos os conteúdos
    const contents = document.querySelectorAll('.dashboard-content');
    contents.forEach(content => {
        content.classList.remove('active');
    });
    
    // Mostrar o conteúdo selecionado
    document.getElementById(tabId).classList.add('active');
    
    // Atualizar as tabs
    const tabs = document.querySelectorAll('.dashboard-tab');
    tabs.forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Encontrar e ativar a tab correspondente
    const activeTab = Array.from(tabs).find(tab => {
        return tab.getAttribute('onclick').includes(tabId);
    });
    
    if (activeTab) {
        activeTab.classList.add('active');
    }
}

// Inicialização dos gráficos quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    // Inicializar gráficos da Visão Geral
    const audienceGrowthChart = new Chart(
        document.getElementById('audienceGrowthChart'),
        {
            type: 'line',
            data: dashboardData.overview.audienceGrowth,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: false
                    }
                }
            }
        }
    );
    
    const platformDistributionChart = new Chart(
        document.getElementById('platformDistributionChart'),
        {
            type: 'doughnut',
            data: dashboardData.overview.platformDistribution,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right',
                    },
                    title: {
                        display: false
                    }
                }
            }
        }
    );
    
    // Inicializar gráficos do YouTube
    const videoViewsChart = new Chart(
        document.getElementById('videoViewsChart'),
        {
            type: 'bar',
            data: dashboardData.youtube.videoViews,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    title: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        }
    );
    
    const subscribersGrowthChart = new Chart(
        document.getElementById('subscribersGrowthChart'),
        {
            type: 'line',
            data: dashboardData.youtube.subscribersGrowth,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    title: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: false
                    }
                }
            }
        }
    );
    
    // Inicializar gráficos do Spotify
    const trackStreamsChart = new Chart(
        document.getElementById('trackStreamsChart'),
        {
            type: 'bar',
            data: dashboardData.spotify.trackStreams,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    title: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        }
    );
    
    const listenersByCountryChart = new Chart(
        document.getElementById('listenersByCountryChart'),
        {
            type: 'pie',
            data: dashboardData.spotify.listenersByCountry,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right',
                    },
                    title: {
                        display: false
                    }
                }
            }
        }
    );
    
    // Inicializar gráficos de Redes Sociais
    const socialEngagementChart = new Chart(
        document.getElementById('socialEngagementChart'),
        {
            type: 'bar',
            data: dashboardData.social.engagement,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    title: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        }
    );
    
    const followersGrowthChart = new Chart(
        document.getElementById('followersGrowthChart'),
        {
            type: 'line',
            data: dashboardData.social.followersGrowth,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: false
                    }
                }
            }
        }
    );
    
    // Inicializar a primeira aba do dashboard
    showDashboardTab('overview');
});
