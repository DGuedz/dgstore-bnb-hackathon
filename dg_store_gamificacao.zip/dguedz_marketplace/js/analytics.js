// Analytics JS para DG Store - Versão Minimalista
// Arquivo responsável pela simulação de dados e renderização dos gráficos

// Dados simulados para o analytics
const analyticsData = {
    // Dados gerais
    overview: {
        views: {
            value: 1000,
            trend: 423,
            trendType: 'up',
            trendLabel: 'a mais do que o habitual'
        },
        spotify: {
            value: 18300,
            trend: 8.7,
            trendType: 'up',
            trendLabel: 'este mês'
        },
        viewers: {
            recurring: 152,
            new: 509,
            trend: 16,
            trendType: 'up',
            trendLabel: 'novos este mês'
        },
        regions: {
            brazil: 33.4,
            portugal: 18.7,
            angola: 15.2,
            usa: 12.8,
            others: 19.9
        }
    },
    
    // Dados de conteúdo
    content: {
        topVideos: [
            {
                title: 'DGuedz, Ty Lexxus feat Sond\'Pla...',
                views: 328,
                thumbnail: 'https://img.youtube.com/vi/KA3og1jDav8/mqdefault.jpg',
                date: 'Publicado em 15 de mai.'
            },
            {
                title: 'DGuedz - Vejo seu olhar (Prod L...)',
                views: 121,
                thumbnail: 'https://img.youtube.com/vi/KA3og1jDav8/mqdefault.jpg',
                date: 'Publicado em 10 de mai.'
            },
            {
                title: 'DGuedz - Aleluia (Official Music...)',
                views: 110,
                thumbnail: 'https://img.youtube.com/vi/KA3og1jDav8/mqdefault.jpg',
                date: 'Publicado em 5 de mai.'
            },
            {
                title: 'DGuedz - IYKYK (Full Ep Track)',
                views: 70,
                thumbnail: 'https://img.youtube.com/vi/KA3og1jDav8/mqdefault.jpg',
                date: 'Publicado em 1 de mai.'
            },
            {
                title: 'DGuedz Feat Arqui Rival - Chape...',
                views: 59,
                thumbnail: 'https://img.youtube.com/vi/KA3og1jDav8/mqdefault.jpg',
                date: 'Publicado em 25 de abr.'
            }
        ]
    },
    
    // Dados do Spotify
    spotify: {
        topTracks: [
            {
                title: 'DG Detective',
                streams: 235800,
                thumbnail: 'https://img.youtube.com/vi/KA3og1jDav8/mqdefault.jpg'
            },
            {
                title: 'Afro Vibes Intro',
                streams: 187300,
                thumbnail: 'https://img.youtube.com/vi/KA3og1jDav8/mqdefault.jpg'
            },
            {
                title: 'Started From The Bottom',
                streams: 142900,
                thumbnail: 'https://img.youtube.com/vi/KA3og1jDav8/mqdefault.jpg'
            }
        ]
    }
};

// Função para formatar números grandes (K, M)
function formatNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    }
    if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'K';
    }
    return num;
}

// Inicialização dos players do YouTube quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    // Inicializar player do YouTube para o beat Detective
    new YT.Player('youtube-player-detective', {
        videoId: 'KA3og1jDav8',
        playerVars: {
            'autoplay': 0,
            'controls': 1,
            'rel': 0
        }
    });
    
    // Inicializar player do YouTube para o beat Afro Vibes Intro
    new YT.Player('youtube-player-afrovibes', {
        videoId: 'KA3og1jDav8',
        playerVars: {
            'autoplay': 0,
            'controls': 1,
            'rel': 0
        }
    });
    
    // Inicializar player do YouTube para o beat Started From The Bottom
    new YT.Player('youtube-player-started', {
        videoId: 'KA3og1jDav8',
        playerVars: {
            'autoplay': 0,
            'controls': 1,
            'rel': 0
        }
    });
    
    // Inicializar player do YouTube para o beat Elevation
    new YT.Player('youtube-player-elevation', {
        videoId: 'KA3og1jDav8',
        playerVars: {
            'autoplay': 0,
            'controls': 1,
            'rel': 0
        }
    });
});
